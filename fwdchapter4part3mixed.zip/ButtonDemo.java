import java.awt.*;

public class ButtonDemo
{
    public static void main(String[] args)
    {
        Frame f=new Frame("Button");
        f.setSize (400,300);
        f.setLayout(new FlowLayout(FlowLayout.CENTER,100,100));
        Button b = new Button("OK");
        f.add(b);
        Button b1=new Button("CANCEL");
        f.add(b1);
        f.setVisible(true);
}
}

    